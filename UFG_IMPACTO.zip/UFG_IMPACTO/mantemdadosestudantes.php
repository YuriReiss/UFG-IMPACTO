<?php
session_start();
//busca o arquivo controller dos dados dos estudantes
require_once './MVC/Controller/dadosestudantecontroller.class.php';

$dadosEstudanteController = new DadosEstudanteController();

//destroi a variável $dadosEstudanteController
unset($dadosEstudanteController);