<?php
session_start();
//busca o arquivo controller da index
require_once './MVC/Controller/indexcontroller.class.php';

$index = new IndexController();

//destroi a variável $index
unset($index);