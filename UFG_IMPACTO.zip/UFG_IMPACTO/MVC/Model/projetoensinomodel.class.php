<?php

require_once './MVC/Model/abstractprojetomodel.class.php';

class ProjetoEnsinoModel extends ProjetoModel{
}
