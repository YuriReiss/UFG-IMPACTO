<?php

require_once './MVC/Model/projetoensinomodel.class.php';
require_once './MVC/Model/projetoextensaomodel.class.php';
require_once './MVC/Model/projetopesquisamodel.class.php';

class FabricaProjetoModel
{
    public static function criaProjeto(
        $idProjeto = null,
        $tipoProjeto = null,
        $tituloProjeto = null,
        $idUnidadeProjeto = null,
        $siglaUnidadeProjeto = null,
        $nomeUnidadeProjeto = null,
        $coordenacaoProjeto = null,
        $resumoProjeto = null,
        $tipo
    ) {
        switch ($tipo) {
            case TipoProjeto::Ensino:
                return new ProjetoEnsinoModel($idProjeto, $tipoProjeto, $tituloProjeto, $idUnidadeProjeto, $siglaUnidadeProjeto, $nomeUnidadeProjeto, $coordenacaoProjeto, $resumoProjeto);
                break;
            case TipoProjeto::Pesquisa:
                return new ProjetoPesquisaModel($idProjeto, $tipoProjeto, $tituloProjeto, $idUnidadeProjeto, $siglaUnidadeProjeto, $nomeUnidadeProjeto, $coordenacaoProjeto, $resumoProjeto);
                break;
            case TipoProjeto::Extensão:
                return new ProjetoExtensaoModel($idProjeto, $tipoProjeto, $tituloProjeto, $idUnidadeProjeto, $siglaUnidadeProjeto, $nomeUnidadeProjeto, $coordenacaoProjeto, $resumoProjeto);
                break;
            default:
                echo ("Não existe este tipo de projeto informado.");
                break;
        }
    }
}
