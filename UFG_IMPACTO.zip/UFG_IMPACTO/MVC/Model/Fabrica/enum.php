<?php
class TipoProjetoModel
{
    const Ensino = 'Ensino';
    const Pesquisa = 'Pesquisa';
    const Extensão = 'Extensao';
}