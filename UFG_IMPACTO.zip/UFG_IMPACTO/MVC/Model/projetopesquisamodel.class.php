<?php

require_once './MVC/Model/abstractprojetomodel.class.php';

class ProjetoPesquisaModel extends ProjetoModel{
}
