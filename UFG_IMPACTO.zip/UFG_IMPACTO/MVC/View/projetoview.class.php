<?php

require_once 'viewabstract.class.php';

require_once './MVC/Model/abstractprojetomodel.class.php';

class ProjetoView extends ViewAbstract
{

    /**
     * Método responsável por montar a lista de projetos
     */
    public function montaListaProjetos($projetosModel)
    {
        $html = "<center><div class='btn-group' role='group' aria-label='Basic example'>
                <form action='' method='GET'> <button type='submit' name='bt' value='apenasEnsino' class='btn btn-primary'>Ensino</button>
                <button type='submit' name='bt' value='apenasExtensao' class='btn btn-primary'>Pesquisa</button>
                <button type='submit' name='bt' value='apenasPesquisa' class='btn btn-primary'>Extensão</button></form>
                </div></center><br>"
            . "<div class='listaDeProjetos'>"
            . "<div class='card'>"
            . "<div class='card-header'>"
            . "<center>Projetos</center>"
            . "</div>"
            . "<ul class='list-group list-group-flush'>";
        if ($projetosModel) {
            foreach ($projetosModel as $projetoModel) {
                $html .= "<li class='list-group-item'>"
                    . "<div class='projeto'>"
                    . "<div class= 'dadosprojeto'>"
                    . "<h6>{$projetoModel->getTitulo_projeto()}<br><br>"
                    . "{$projetoModel->getTipo_projeto()} | {$projetoModel->getResumo_projeto()}</h6>"
                    . "</div>"
                    . "</form></center>"
                    . "</div>"
                    . "</div>"
                    . "</li>";
            }
        } else {
            $html .= "<li class='list-group-item'>"
                . "<center><h5><font color='gray'>Não há projetos!</font></h5></center>"
                . "</li>";
        }
        $html .= "</ul>"
            . "</div>"
            . "</div>";

        $this->adicionaNoCorpo($html);
    }
}
