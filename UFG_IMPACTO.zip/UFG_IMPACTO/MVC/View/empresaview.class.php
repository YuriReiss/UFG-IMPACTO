<?php

require_once 'viewabstract.class.php';
require_once './MVC/Model/empresamodel.class.php';

class EmpresaView extends ViewAbstract
{

    /**
     * Método responsável por montar a lista de empresas
     */
    public function montaListaEmpresas($empresasModel)
    {
        $html = "<div class='listaDeEmpresas'>"
            . "<div class='card'>"
            . "<div class='card-header'>"
            . "<center>Empresas fundadas por egressos</center>"
            . "</div>"
            . "<ul class='list-group list-group-flush'>";
        if ($empresasModel) {
            foreach ($empresasModel as $empresa) {
                $html .= "<li class='list-group-item'>"
                    . "<div class='empresa'>"
                    . "<div class= 'dadosEmpresa'>"
                    . "<b>{$empresa->getRazao_social()}</b><br><br>"
                    . "<h6><b>Capital social:</b> R$ {$empresa->getCapital_social()}</h6><br>";
                if (empty($empresa->getTotal_colaboradores())) {
                    $html .= "<h6><b>Total de colaboradores:</b> Não disponível. </h6><br>";
                } else {
                    $html .= "<h6>Total de colaboradores: {$empresa->getTotal_colaboradores()}</h6><br>";
                }
                $html .= "</div>"
                    . "</form></center>"
                    . "</div>"
                    . "</div>"
                    . "</li>";
            }
        } else {
            $html .= "<li class='list-group-item'>"
                . "<center><h5><font color='gray'>Não há empresas!</font></h5></center>"
                . "</li>";
        }
        $html .= "</ul>"
            . "</div>"
            . "</div>";

        $this->adicionaNoCorpo($html);
    }
}
