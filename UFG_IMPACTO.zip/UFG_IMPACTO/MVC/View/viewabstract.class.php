<?php

abstract class ViewAbstract {

    protected $html1 = null;
    protected $html2 = null;
    protected $corpo = null;
    protected $mensagens = null;
    protected $titulo = null;

    public function __construct($titulo) {
        $this->titulo = $titulo;

        $this->montaHtml1();
        $this->montaHtml2();
    }

    /**
     * Método que, de fato, apresenta na tela todo html acumulado nos arquivos php 
     */
    public function displayInterface() {
        echo $this->html1 . $this->mensagens . $this->corpo . $this->html2;
    }

    /**
     * Método utilizado para limpar uma div da tela. Foi criado por conta da maior praticidade em poder chamá-lo ao 
     * longo do código php, sem ter que ficar inserindo linhas de código no arquivo js para cada div que se deseja limpar.
     * @param string $div
     */
    public function limpaDiv($div) {
        $this->adicionaNoCorpo("<script> document.getElementById('{$div}').innerHTML=''; </script>");
    }

    /**
     * Método que monta o início do html, a parte em que se chama as CDN's (links para arquivos como Bootstrap e jQuery).
     */
    public function montaHtml1() {
        $this->html1 = "<!DOCTYPE html>"
                . "<html lang='pt-br'>"
                . "<head>"
                . "<meta charset='utf-8'>"
                . "<meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>"

                //====NÃO ALTERAR ORDEM DE CHAMADA DAS CDN'S=====//
                
                //ADICIONANDO FAVICON
                . "<link rel='sortcut icon' href='./imagens/icones/logoIcone.png' type='image/png' >"

                //ADICIONANDO BIBLIOTECA DE ICONES PARA USAR O ÍCONE DE BUSCA DO CAMPO DE BUSCA
                . "<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>"

                //CSS do bootsrap
                . "<link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css' integrity='sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO' crossorigin='anonymous'>"


                //JQUERY
                . "<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js'></script>"

                //JQUERY MASK PLUGIN
                . "<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.js'></script>"


                //JS do bootsrap 
                . "<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js' integrity='sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49' crossorigin='anonymous'></script>"
                . "<script src='https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js' integrity='sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy' crossorigin='anonymous'></script>"
                
                . "<title>{$this->titulo}</title></head><body>{$this->montaCabecalho()}{$this->montaMenu()}\n";
    }

    /**
     * Método responsável por fechar as tag's body e html
     */
    public function montaHtml2() {
        $this->html2 = "{$this->montaRodape()}</body></html>\n";
    }

    /**
     * Método responsável por ir adicionando ao html como um todo os códigos em html mandado pelas views que herdam a viewabstract
     * @param string $item
     */
    public function adicionaNoCorpo($item) {
        $this->corpo .= $item;
    }

    /**
     * Método que montará o menu principal do sistema
     * @return string html com o menu principal do sistema
     */
    public function montaMenu() {
        $html = "<div id='menu'>"
                . "<ul>"
                . "</ul>"
                . "</div>"
                . "<div id='conteudo-e-rodape'>";
        return $html;
    }

    /**
     * Método que adiciona mensagens (de erro, de sucesso, de aviso...) ao html geral da página em questão no momento da execução
     * @param string $mensagem
     */
    public function adicionaNasMensagens($mensagem) {
        $this->mensagens .= $mensagem;
    }

    /**
     * Método que monta o conteúdo do cabeçalho do sistema 
     * @return string html contendo cabeçalho
     */
    public function montaCabecalho() {
        $html = "<div id='cabecalho'>"
                . "<style>body{background-color:#FFFAFA}</style>"
                . "</div>";
        return $html;
    }

    /**
     * Método que monta o conteúdo do rodapé do sistema
     * @return string html contendo o rodapé
     */
    public function montaRodape() {
        $html = "<div id='rodape'>"
                ."</div>";
        return $html;
    }

    public function getBtPOST() {
        if (isset($_POST['bt'])) {
            return $_POST['bt'];
        } else {
            return null;
        }
    }

    public function getBtGET() {
        if (isset($_GET['bt'])) {
            return $_GET['bt'];
        } else {
            return null;
        }
    }

}
