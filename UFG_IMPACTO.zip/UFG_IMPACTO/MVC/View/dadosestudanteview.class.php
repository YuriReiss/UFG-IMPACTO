<?php

require_once 'viewabstract.class.php';
require_once './MVC/Model/abstractprojetomodel.class.php';

class DadosEstudanteView extends ViewAbstract {

    /**
     * Método responsável por montar a lista de infos de egressos por campus
     */
    public function montaListaDeInfosDosCampus($infosCampus) {
        $html = "<div class='listaDeInfosEgressosPorCampus'>"
                . "<div class='card'>"
                . "<div class='card-header'>"
                . "Egressos por campus"
                . "</div>"
                . "<ul class='list-group list-group-flush'>";
        if ($infosCampus) {
            $cidades = array_keys($infosCampus);
            $i=0;
            foreach ($infosCampus as $infoCampus) {
                $porcentagem = ($infoCampus*100)/5000;
                $html .= "<li class='list-group-item'>"
                        . "<div class='campu'>"
                        . "<div class= 'dadosprojeto'>"
                        . "<b>{$cidades[$i]}</b><br><br>"
                        . "Quantidade: {$infoCampus} | {$porcentagem} %</b><br>"
                        . "</div>"
                        . "</form></center>"
                        . "</div>"
                        . "</div>"
                        . "</li>";
                        $i++;
            }
        } else {
            $html .= "<li class='list-group-item'>"
                    . "<center><h5><font color='gray'>Não há dados!</font></h5></center>"
                    . "</li>";
        }
        $html .= "</ul>"
                . "</div>"
                . "</div>";

        $this->adicionaNoCorpo($html);
    }

    /**
     * Método responsável por montar a lista de dados diversos
     */
    public function montaDadosDiversos($anosIntegralizacao)
    {
        $media = array_sum($anosIntegralizacao) / count($anosIntegralizacao);

        $html = "<div class='listaDadosDiversos'>"
            . "<div class='card'>"
            . "<div class='card-header'>"
            . "Dados diversos"
            . "</div>"
            . "<ul class='list-group list-group-flush'>"
            . "<li class='list-group-item'>"
            . "<div class='campu'>"
            . "<div class= 'dadosprojeto'>"
            . "<b>Tempo médio de integralização: {$media} anos</b><br><br>"
            . "</div>"
            . "</form></center>"
            . "</div>"
            . "</div>"
            . "</li>"
            . "</ul>"
            . "</div>"
            . "</div>";

        $this->adicionaNoCorpo($html);
    }

}
