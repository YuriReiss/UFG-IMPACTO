<?php

require_once 'viewabstract.class.php';

class IndexView extends ViewAbstract {

    /**
     * Método responsável por montar a lista de módulos
     */
    public function montaListaModulos() {
        $html = "<center>"
                ."<div class='modulos'>"

                . "<div class='card'>"
                . "<div class='card-header'>"
                . "Projeto"
                . "</div>"
                . "<ul class='list-group list-group-flush'>"
                . "<li class='list-group-item'>"
                . "<div class='modulo'>"
                . "<div class= 'dadosModulo'>"
                . "<center><img src='MVC\View\pesquisa.png' width='100' height='100'></center>"
                . "<b>Venha conhecer mais acerca dos projetos desenvolvidos na Universidade Federal de Goiás.</b><br>"
                . "</div>"
                . "<br><div class='botaoModulo'>"
                . "<center><form action='' method='GET'>"
                . "<button type='submit' name='bt' value='projetos' class='btn btn-outline-success'>Ir →</button>"
                . "</form></center>"
                . "</div>"
                . "</div>"
                . "</li>"
                . "</ul>"
                . "</div>"

                . "<div class='card'>"
                . "<div class='card-header'>"
                . "Empresas de egressos"
                . "</div>"
                . "<ul class='list-group list-group-flush'>"
                . "<li class='list-group-item'>"
                . "<div class='modulo'>"
                . "<div class= 'dadosModulo'>"
                . "<center><img src='MVC\View\imgempresa.png' width='100' height='100'></center>"
                . "<b>Entre para visualizar dados acerca de empresas fundadas por egressos da universidade.</b><br>"
                . "</div>"
                . "<br><div class='botaoModulo'>"
                . "<center><form action='' method='GET'>"
                . "<button type='submit' name='bt' value='empresas' class='btn btn-outline-success'>Ir →</button>"
                . "</form></center>"
                . "</div>"
                . "</div>"
                . "</li>"
                . "</ul>"
                . "</div>"

                . "<div class='card'>"
                . "<div class='card-header'>"
                . "Egressos"
                . "</div>"
                . "<ul class='list-group list-group-flush'>"
                . "<li class='list-group-item'>"
                . "<div class='modulo'>"
                . "<div class= 'dadosModulo'>"
                . "<center><img src='MVC\View\imgegresso.png' width='100' height='100'></center>"
                . "<b>Descubra dados estatísticos acerca dos nossos ex alunos.</b><br>"
                . "</div>"
                . "<br><div class='botaoModulo'>"
                . "<center><form action='' method='GET'>"
                . "<button type='submit' name='bt' value='egressos' class='btn btn-outline-success'>Ir →</button>"
                . "</form></center>"
                . "</div>"
                . "</div>"
                . "</li>"
                . "</ul>"
                . "</div>"

                . "</div>"
                . "</center>"
                . "<style>"
                . "*{
                    margin: 0%;
                    padding: 0%;
                }   

                .card{
                    width: 400px;
                    min-height: 320px;
                    margin-left: 40px;
                    float:left;
                }"
                . "</style>";

        $this->adicionaNoCorpo($html);
    }
}
