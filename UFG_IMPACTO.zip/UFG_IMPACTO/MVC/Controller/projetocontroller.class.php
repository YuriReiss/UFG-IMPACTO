<?php

require_once './Camadas/Aplicacao/projetoaplicacao.class.php';
require_once './MVC/Model/Fabrica/fabricaprojeto.class.php';
require_once './MVC/View/projetoview.class.php';
require_once './MVC/Model/Fabrica/enum.php';

class ProjetoController
{
    public function filtraPorTipoProjeto($tipo){
        $aplicacao = new ProjetoAplicacao();
        return $this->converteObjetoNegocioParaModel($aplicacao->filtraPorTipoProjeto($tipo));
    }

    public function converteObjetoNegocioParaModel($projetosNegocio){
        $fabrica = new FabricaProjetoModel();

        $projetosArray = array();

        //converte Negocio para Model
        foreach ($projetosNegocio as $projeto) {
            switch ($projeto->getTipo_projeto()) {
                case TipoProjetoModel::Pesquisa:
                    $projeto = $fabrica->criaProjeto(
                        $projeto->getId_projeto(),
                        $projeto->getTipo_projeto(),
                        $projeto->getTitulo_projeto(),
                        $projeto->getId_unidade_projeto(),
                        $projeto->getSigla_unidade_projeto(),
                        $projeto->getNome_unidade_projeto(),
                        $projeto->getCoordenacao_projeto(),
                        $projeto->getResumo_projeto(),
                        TipoProjetoModel::Pesquisa
                    );
                    break;
                case TipoProjetoModel::Ensino:
                    $projeto = $fabrica->criaProjeto(
                        $projeto->getId_projeto(),
                        $projeto->getTipo_projeto(),
                        $projeto->getTitulo_projeto(),
                        $projeto->getId_unidade_projeto(),
                        $projeto->getSigla_unidade_projeto(),
                        $projeto->getNome_unidade_projeto(),
                        $projeto->getCoordenacao_projeto(),
                        $projeto->getResumo_projeto(),
                        TipoProjetoModel::Ensino
                    );
                    break;
                case TipoProjetoModel::Extensão:
                    $projeto = $fabrica->criaProjeto(
                        $projeto->getId_projeto(),
                        $projeto->getTipo_projeto(),
                        $projeto->getTitulo_projeto(),
                        $projeto->getId_unidade_projeto(),
                        $projeto->getSigla_unidade_projeto(),
                        $projeto->getNome_unidade_projeto(),
                        $projeto->getCoordenacao_projeto(),
                        $projeto->getResumo_projeto(),
                        TipoProjetoModel::Extensão
                    );
                    break;   
            }
            array_push($projetosArray,$projeto);
        }

        return $projetosArray;
    }

    public function __construct()
    {
        $aplicacao = new ProjetoAplicacao();
        $view = new ProjetoView("Projetos");

        $acao = $view->getBtGET();
        switch ($acao) {
            case "apenasEnsino":
                $projetosArray = $this->filtraPorTipoProjeto(TipoProjeto::Ensino);
                break;
            case "apenasPesquisa":
                $projetosArray = $this->filtraPorTipoProjeto(TipoProjeto::Pesquisa);
                break;
            case "apenasExtensao":
                $projetosArray = $this->filtraPorTipoProjeto(TipoProjeto::Extensão);
                break;
            default:
                $projetos = $aplicacao->obtemProjetos();
                $projetosArray = $this->converteObjetoNegocioParaModel($projetos);
                break;
        }
        $view->montaListaProjetos($projetosArray);
        $view->displayInterface();
    }
}
