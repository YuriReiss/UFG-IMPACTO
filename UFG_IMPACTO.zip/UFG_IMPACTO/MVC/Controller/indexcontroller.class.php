<?php

require_once './MVC/View/indexview.class.php';

class IndexController
{
    public function __construct()
    {
        $view = new IndexView("Home");
        $acao = $view->getBtGET();
        switch ($acao) {
            case "projetos":
                header("Location: ./mantemprojetos.php");
                break;
            case "empresas":
                header("Location: ./mantemempresas.php");
                break;
            case "egressos":
                header("Location: ./mantemdadosestudantes.php");
                break;
            default:
                break;
        }

        $view->montaListaModulos();
        $view->displayInterface();
    }
}
