<?php

require_once './Camadas/Aplicacao/dadosestudanteaplicacao.class.php';
require_once './MVC/View/dadosestudanteview.class.php';

class DadosEstudanteController
{
    public function __construct()
    {
        $aplicacao = new DadosEstudanteAplicacao();
        $view = new DadosEstudanteView("Dados dos estudantes");

        $quantidadeVagaPorCampus = $aplicacao->obtemQuantidadeVagarPorCampus();
        $anosIntegralizacao = $aplicacao->obtemAnosDeIntegralizacao();
        $view->montaListaDeInfosDosCampus($quantidadeVagaPorCampus);

        $view->montaDadosDiversos($anosIntegralizacao);
        $view->displayInterface();
        
        var_dump($aplicacao->obtemDadosEstudantes());
    }
}
