<?php

require_once './Camadas/Aplicacao/empresaaplicacao.class.php';
require_once './MVC/View/empresaview.class.php';

class EmpresaController
{
    public function __construct()
    {
        $aplicacao = new EmpresaAplicacao();
        $view = new EmpresaView("Empresas");

        $empresas = $aplicacao->obtemEmpresas();
        
        $view->montaListaEmpresas($empresas);
        $view->displayInterface();
    }
}
