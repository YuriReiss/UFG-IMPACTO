<?php

require_once './Camadas/Persistencia/empresapersistencia.class.php';
require_once './Camadas/Negocio/empresa.class.php';

class EmpresaAplicacao
{
    public function obtemEmpresas()
    {
        $empresasPersistencia = new EmpresaPersistencia();

        $matrixEmpresas = $empresasPersistencia->leEmpresas();

        $empresasObjetos = array();

        foreach($matrixEmpresas as $empresa){
            $razao_social = $empresa[0];
            $capital_social = $empresa[4];
            $total_colaboradores = $empresa[3];
            
            array_push($empresasObjetos, new Empresa($razao_social,$capital_social,$total_colaboradores));
        }

        return $empresasObjetos; 
    }
}
