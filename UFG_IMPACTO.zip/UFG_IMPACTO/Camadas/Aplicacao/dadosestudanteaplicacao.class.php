<?php

require_once './Camadas/Persistencia/dadosestudantepersistencia.class.php';
require_once './Camadas/Negocio/dadosestudante.class.php';

class DadosEstudanteAplicacao
{
    public function obtemQuantidadeVagarPorCampus()
    {
        $dadosEstudantesPersistencia = new DadosEstudantePersistencia();

        $matrixDadosEstudantes = $dadosEstudantesPersistencia->leDadosEstudantes();

        $i = 0;
        $cidades = array();
        foreach ($matrixDadosEstudantes as $dadosEstudante) {
            $cidade = $dadosEstudante[0];
            array_push($cidades, $cidade);
        }
        return array_count_values(array_column($cidades,null,null));
    }

    public function obtemAnosDeIntegralizacao()
    {
        $dadosEstudantesPersistencia = new DadosEstudantePersistencia();

        $matrixDadosEstudantes = $dadosEstudantesPersistencia->leDadosEstudantes();

        $i = 0;
        $anos = array();
        foreach ($matrixDadosEstudantes as $dadosEstudante) {
            array_push($anos, $dadosEstudante[22]-$dadosEstudante[8]);
        }
        return array_count_values(array_column($anos,null,null));
    }

    public function obtemDadosEstudantes()
    {
        $dadosEstudantesPersistencia = new DadosEstudantePersistencia();

        $matrixDadosEstudantes = $dadosEstudantesPersistencia->leDadosEstudantes();

        $dadosEstudantesObjetos = array();

        foreach ($matrixDadosEstudantes as $dadosEstudante) {
            $cidade = $dadosEstudante[0];
            $ano_desvinculo = $dadosEstudante[22];
            $ano_vinculo = $dadosEstudante[8];
            $media_relativa = $dadosEstudante[16];
            $categoria_ingresso = $dadosEstudante[12];
            $motivo_desvinculo = $dadosEstudante[21];

            array_push($dadosEstudantesObjetos, new DadosEstudante($cidade, $ano_desvinculo, $ano_vinculo, $media_relativa, $categoria_ingresso, $motivo_desvinculo));
        }

        return $dadosEstudantesObjetos;
    }
}
