<?php

require_once './Camadas/Negocio/Fabrica/fabricaprojeto.class.php';
require_once './Camadas/Negocio/Fabrica/enum.php';

class ProjetoAplicacao
{
    public function filtraPorTipoProjeto($tipo){
        $resposta = $this->obtemToken(
            array('Authorization: Basic NThiN0ZyZElQRnYxYWZVTjNpbGw2YmZkTnlJYTpmcGxsMFU1dnFBVlB3OHAybVJKNnhlcHViSUFh'),
            'grant_type=client_credentials',
            'https://data.api.ufg.br/token',
            'POST'
        );

        $token = json_decode($resposta)->{'access_token'};

        $projetos = $this->consomeAPI(
            array('accept: application/json', 'Authorization: Bearer ' . $token),
            null,
            'https://data.api.ufg.br/ensino/projetos/1.0.0/projetos_em_andamento?tipo_projeto=ENSINO',
            'GET'
        );

        $fabrica = new FabricaProjeto();
        $projetosArray = array();

        $projetos = json_decode($projetos)->{'content'};
        foreach ($projetos as $projeto) {

            if (
                !isset($projeto->idProjeto) ||
                !isset($projeto->tipo_projeto) ||
                !isset($projeto->titulo_projeto) ||
                !isset($projeto->id_unidade_projeto) ||
                !isset($projeto->sigla_unidade_projeto) ||
                !isset($projeto->nome_unidade_projeto) ||
                !isset($projeto->coordenacao_projeto) ||
                !isset($projeto->resumo_projeto)
            ) {
                continue;
            }

            if($tipo != $projeto->tipo_projeto) continue;
            
            switch ($projeto->tipo_projeto) {
                case TipoProjeto::Pesquisa:
                    $projeto = $fabrica->criaProjeto(
                        $projeto->idProjeto,
                        $projeto->tipo_projeto,
                        $projeto->titulo_projeto,
                        $projeto->id_unidade_projeto,
                        $projeto->sigla_unidade_projeto,
                        $projeto->nome_unidade_projeto,
                        $projeto->coordenacao_projeto,
                        $projeto->resumo_projeto,
                        TipoProjeto::Pesquisa
                    );
                    break;
                case TipoProjeto::Ensino:
                    $projeto = $fabrica->criaProjeto(
                        $projeto->idProjeto,
                        $projeto->tipo_projeto,
                        $projeto->titulo_projeto,
                        $projeto->id_unidade_projeto,
                        $projeto->sigla_unidade_projeto,
                        $projeto->nome_unidade_projeto,
                        $projeto->coordenacao_projeto,
                        $projeto->resumo_projeto,
                        TipoProjeto::Ensino
                    );
                    break;
                case TipoProjeto::Extensão:
                    $projeto = $fabrica->criaProjeto(
                        $projeto->idProjeto,
                        $projeto->tipo_projeto,
                        $projeto->titulo_projeto,
                        $projeto->id_unidade_projeto,
                        $projeto->sigla_unidade_projeto,
                        $projeto->nome_unidade_projeto,
                        $projeto->coordenacao_projeto,
                        $projeto->resumo_projeto,
                        TipoProjeto::Extensão
                    );
                    break;
            }
            array_push($projetosArray,$projeto);
        }
        return $projetosArray;
    }

    /**
     * Método responsável por obter o token da API 
     */
    public function obtemToken($cabecalho = array(), $conteudoAEnviar, $url, $tpRequisicao)
    {

        try {
            //Inicializa cURL para uma URL.
            $ch = curl_init($url);
            //Marca que vai enviar por POST(1=SIM), caso tpRequisicao seja igual a "POST"
            if ($tpRequisicao == 'POST') {
                curl_setopt($ch, CURLOPT_POST, 1);
                //Passa o conteúdo para o campo de envio por POST
                curl_setopt($ch, CURLOPT_POSTFIELDS, $conteudoAEnviar);
            }
            //Se foi passado como parâmetro, adiciona o cabeçalho à requisição
            if (!empty($cabecalho)) {
                curl_setopt($ch, CURLOPT_HTTPHEADER, $cabecalho);
            }
            //Marca que vai receber string
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            /*
            Caso você não receba retorno da API, pode estar com problema de SSL.
            Remova o comentário da linha abaixo para desabilitar a verificação.
            */
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            //Inicia a conexão
            $resposta = curl_exec($ch);
            //Fecha a conexão
            curl_close($ch);
        } catch (Exception $e) {
            return $e->getMessage();
        }
        return $resposta;
    }

    /**
     * Método responsável por obter o token da API 
     */
    public function consomeAPI($cabecalho = array(), $conteudoAEnviar, $url, $tpRequisicao)
    {

        try {
            //Inicializa cURL para uma URL.
            $ch = curl_init($url);
            //Marca que vai enviar por POST(1=SIM), caso tpRequisicao seja igual a "POST"
            if ($tpRequisicao == 'POST') {
                curl_setopt($ch, CURLOPT_POST, 1);
                //Passa o conteúdo para o campo de envio por POST
                curl_setopt($ch, CURLOPT_POSTFIELDS, $conteudoAEnviar);
            }
            //Se foi passado como parâmetro, adiciona o cabeçalho à requisição
            if (!empty($cabecalho)) {
                curl_setopt($ch, CURLOPT_HTTPHEADER, $cabecalho);
            }
            //Marca que vai receber string
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            /*
            Caso você não receba retorno da API, pode estar com problema de SSL.
            Remova o comentário da linha abaixo para desabilitar a verificação.
            */
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            //Inicia a conexão
            $resposta = curl_exec($ch);
            //Fecha a conexão
            curl_close($ch);
        } catch (Exception $e) {
            return $e->getMessage();
        }
        return $resposta;
    }

    public function obtemProjetos()
    {
        $resposta = $this->obtemToken(
            array('Authorization: Basic NThiN0ZyZElQRnYxYWZVTjNpbGw2YmZkTnlJYTpmcGxsMFU1dnFBVlB3OHAybVJKNnhlcHViSUFh'),
            'grant_type=client_credentials',
            'https://data.api.ufg.br/token',
            'POST'
        );

        $token = json_decode($resposta)->{'access_token'};

        $projetos = $this->consomeAPI(
            array('accept: application/json', 'Authorization: Bearer ' . $token),
            null,
            'https://data.api.ufg.br/ensino/projetos/1.0.0/projetos_em_andamento?tipo_projeto=ENSINO',
            'GET'
        );

        $fabrica = new FabricaProjeto();
        $projetosArray = array();

        $projetos = json_decode($projetos)->{'content'};
        foreach ($projetos as $projeto) {

            if (
                !isset($projeto->idProjeto) ||
                !isset($projeto->tipo_projeto) ||
                !isset($projeto->titulo_projeto) ||
                !isset($projeto->id_unidade_projeto) ||
                !isset($projeto->sigla_unidade_projeto) ||
                !isset($projeto->nome_unidade_projeto) ||
                !isset($projeto->coordenacao_projeto) ||
                !isset($projeto->resumo_projeto)
            ) {
                continue;
            }

            switch ($projeto->tipo_projeto) {
                case TipoProjeto::Pesquisa:
                    $projeto = $fabrica->criaProjeto(
                        $projeto->idProjeto,
                        $projeto->tipo_projeto,
                        $projeto->titulo_projeto,
                        $projeto->id_unidade_projeto,
                        $projeto->sigla_unidade_projeto,
                        $projeto->nome_unidade_projeto,
                        $projeto->coordenacao_projeto,
                        $projeto->resumo_projeto,
                        TipoProjeto::Pesquisa
                    );
                    break;
                case TipoProjeto::Ensino:
                    $projeto = $fabrica->criaProjeto(
                        $projeto->idProjeto,
                        $projeto->tipo_projeto,
                        $projeto->titulo_projeto,
                        $projeto->id_unidade_projeto,
                        $projeto->sigla_unidade_projeto,
                        $projeto->nome_unidade_projeto,
                        $projeto->coordenacao_projeto,
                        $projeto->resumo_projeto,
                        TipoProjeto::Ensino
                    );
                    break;
                case TipoProjeto::Extensão:
                    $projeto = $fabrica->criaProjeto(
                        $projeto->idProjeto,
                        $projeto->tipo_projeto,
                        $projeto->titulo_projeto,
                        $projeto->id_unidade_projeto,
                        $projeto->sigla_unidade_projeto,
                        $projeto->nome_unidade_projeto,
                        $projeto->coordenacao_projeto,
                        $projeto->resumo_projeto,
                        TipoProjeto::Extensão
                    );
                    break;
            }
            array_push($projetosArray,$projeto);
        }
        return $projetosArray;
    }
}
