<?php

require_once './Camadas/Persistencia/spout-3.3.0/src/Spout/Autoloader/autoload.php';

use Box\Spout\Reader\Common\Creator\ReaderEntityFactory;

class EmpresaPersistencia
{

    public function leEmpresas()
    {
        $filePath = getcwd() . './Camadas/Persistencia/Empresas_Egressos_Graduacao.xlsx';
        $reader = ReaderEntityFactory::createReaderFromFile($filePath);

        $reader->open($filePath);

        $matrixEmpresas = array();
        $i = 0;
        foreach ($reader->getSheetIterator() as $sheet) {
            foreach ($sheet->getRowIterator() as $row) {
                if ($i == 0) {
                    $i++;
                    continue;
                }
                $cells = $row->getCells();
                $dadosPorLinha = array();
                foreach ($cells as $cell) {
                    array_push($dadosPorLinha, $cell->getValue());
                }
                array_push($matrixEmpresas, $dadosPorLinha);
            }
        }

        $reader->close();

        return $matrixEmpresas;
    }
}
