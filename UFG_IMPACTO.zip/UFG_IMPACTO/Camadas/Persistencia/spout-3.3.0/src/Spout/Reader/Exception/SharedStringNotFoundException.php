<?php

namespace Box\Spout\Reader\Exception;

/**
 * Class SharedStringNotFoundException
 */
class SharedStringNotFoundException extends ReaderException
{
}
