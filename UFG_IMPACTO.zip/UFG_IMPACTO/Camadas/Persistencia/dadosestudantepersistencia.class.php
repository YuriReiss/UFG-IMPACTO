<?php

require_once './Camadas/Persistencia/spout-3.3.0/src/Spout/Autoloader/autoload.php';

use Box\Spout\Reader\Common\Creator\ReaderEntityFactory;

class DadosEstudantePersistencia{
    
    public function leDadosEstudantes(){
        $filePath = getcwd().'./Camadas/Persistencia/Relação_de_estudantes_ingressos_a_partir_de_2010.xlsx';
        $reader = ReaderEntityFactory::createReaderFromFile($filePath);
        
        $reader->open($filePath);

        $matrixDadosEstudantes = array();
        $i=0;
        foreach ($reader->getSheetIterator() as $sheet) {
            foreach ($sheet->getRowIterator() as $row) {
                $i++;
                if($i==1) continue;
                $cells = $row->getCells();
                $dadosPorLinha = array();
                foreach ($cells as $cell) {
                    array_push($dadosPorLinha, $cell->getValue());
                }
                array_push($matrixDadosEstudantes, $dadosPorLinha);
                if($i==5000) break;
            }
        }

        $reader->close();

        return $matrixDadosEstudantes;
    }
}