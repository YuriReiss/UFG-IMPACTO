<?php

abstract class Projeto{
    private $id_projeto;
    private $tipo_projeto;
    private $titulo_projeto;
    private $id_unidade_projeto;
    private $sigla_unidade_projeto;
    private $nome_unidade_projeto;
    private $coordenacao_projeto;
    private $resumo_projeto;
    
    function __construct(
        $id_projeto = null,
        $tipo_projeto = null,
        $titulo_projeto = null,
        $id_unidade_projeto = null,
        $sigla_unidade_projeto = null,
        $nome_unidade_projeto = null,
        $coordenacao_projeto = null,
        $resumo_projeto = null) {

        $this->id_projeto = $id_projeto;
        $this->tipo_projeto = $tipo_projeto;
        $this->titulo_projeto = $titulo_projeto;
        $this->id_unidade_projeto = $id_unidade_projeto;
        $this->sigla_unidade_projeto = $sigla_unidade_projeto;
        $this->nome_unidade_projeto = $nome_unidade_projeto;
        $this->coordenacao_projeto = $coordenacao_projeto;
        $this->resumo_projeto = $resumo_projeto;
    }

    /**
     * Get the value of id_projeto
     */ 
    public function getId_projeto()
    {
        return $this->id_projeto;
    }

    /**
     * Set the value of id_projeto
     *
     * @return  self
     */ 
    public function setId_projeto($id_projeto)
    {
        $this->id_projeto = $id_projeto;

        return $this;
    }

    /**
     * Get the value of tipo_projeto
     */ 
    public function getTipo_projeto()
    {
        return $this->tipo_projeto;
    }

    /**
     * Set the value of tipo_projeto
     *
     * @return  self
     */ 
    public function setTipo_projeto($tipo_projeto)
    {
        $this->tipo_projeto = $tipo_projeto;

        return $this;
    }

    /**
     * Get the value of titulo_projeto
     */ 
    public function getTitulo_projeto()
    {
        return $this->titulo_projeto;
    }

    /**
     * Set the value of titulo_projeto
     *
     * @return  self
     */ 
    public function setTitulo_projeto($titulo_projeto)
    {
        $this->titulo_projeto = $titulo_projeto;

        return $this;
    }

    /**
     * Get the value of id_unidade_projeto
     */ 
    public function getId_unidade_projeto()
    {
        return $this->id_unidade_projeto;
    }

    /**
     * Set the value of id_unidade_projeto
     *
     * @return  self
     */ 
    public function setId_unidade_projeto($id_unidade_projeto)
    {
        $this->id_unidade_projeto = $id_unidade_projeto;

        return $this;
    }

    /**
     * Get the value of sigla_unidade_projeto
     */ 
    public function getSigla_unidade_projeto()
    {
        return $this->sigla_unidade_projeto;
    }

    /**
     * Set the value of sigla_unidade_projeto
     *
     * @return  self
     */ 
    public function setSigla_unidade_projeto($sigla_unidade_projeto)
    {
        $this->sigla_unidade_projeto = $sigla_unidade_projeto;

        return $this;
    }

    /**
     * Get the value of nome_unidade_projeto
     */ 
    public function getNome_unidade_projeto()
    {
        return $this->nome_unidade_projeto;
    }

    /**
     * Set the value of nome_unidade_projeto
     *
     * @return  self
     */ 
    public function setNome_unidade_projeto($nome_unidade_projeto)
    {
        $this->nome_unidade_projeto = $nome_unidade_projeto;

        return $this;
    }

    /**
     * Get the value of coordenacao_projeto
     */ 
    public function getCoordenacao_projeto()
    {
        return $this->coordenacao_projeto;
    }

    /**
     * Set the value of coordenacao_projeto
     *
     * @return  self
     */ 
    public function setCoordenacao_projeto($coordenacao_projeto)
    {
        $this->coordenacao_projeto = $coordenacao_projeto;

        return $this;
    }

    /**
     * Get the value of resumo_projeto
     */ 
    public function getResumo_projeto()
    {
        return $this->resumo_projeto;
    }

    /**
     * Set the value of resumo_projeto
     *
     * @return  self
     */ 
    public function setResumo_projeto($resumo_projeto)
    {
        $this->resumo_projeto = $resumo_projeto;

        return $this;
    }
}
