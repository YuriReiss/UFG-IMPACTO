<?php

require_once './Camadas/Negocio/abstractprojeto.class.php';

class ProjetoEnsino extends Projeto{
}
