<?php

require_once './Camadas/Negocio/abstractprojeto.class.php';
require_once './Camadas/Negocio/projetoensino.class.php';
require_once './Camadas/Negocio/projetoextensao.class.php';
require_once './Camadas/Negocio/projetopesquisa.class.php';

class FabricaProjeto
{
    public static function criaProjeto(
        $idProjeto = null,
        $tipoProjeto = null,
        $tituloProjeto = null,
        $idUnidadeProjeto = null,
        $siglaUnidadeProjeto = null,
        $nomeUnidadeProjeto = null,
        $coordenacaoProjeto = null,
        $resumoProjeto = null,
        $tipo
    ) {
        switch ($tipo) {
            case TipoProjeto::Ensino:
                return new ProjetoEnsino($idProjeto, $tipoProjeto, $tituloProjeto, $idUnidadeProjeto, $siglaUnidadeProjeto, $nomeUnidadeProjeto, $coordenacaoProjeto, $resumoProjeto);
                break;
            case TipoProjeto::Pesquisa:
                return new ProjetoPesquisa($idProjeto, $tipoProjeto, $tituloProjeto, $idUnidadeProjeto, $siglaUnidadeProjeto, $nomeUnidadeProjeto, $coordenacaoProjeto, $resumoProjeto);
                break;
            case TipoProjeto::Extensão:
                return new ProjetoExtensao($idProjeto, $tipoProjeto, $tituloProjeto, $idUnidadeProjeto, $siglaUnidadeProjeto, $nomeUnidadeProjeto, $coordenacaoProjeto, $resumoProjeto);
                break;
            default:
                echo ("Não existe este tipo de projeto informado.");
                break;
        }
    }
}
