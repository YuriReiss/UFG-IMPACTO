<?php

class DadosEstudante{
    private $cidade;
    private $ano_desvinculo;
    private $ano_vinculo;
    private $media_relativa;
    private $categoria_ingresso;
    private $motivo_desvinculo;
    
    function __construct(
        $cidade = null,
        $ano_desvinculo = null,
        $ano_vinculo = null,
        $media_relativa = null,
        $categoria_ingresso = null,
        $motivo_desvinculo = null) {

        $this->cidade = $cidade;
        $this->ano_desvinculo = $ano_desvinculo;
        $this->ano_vinculo = $ano_vinculo;
        $this->media_relativa = $media_relativa;
        $this->categoria_ingresso = $categoria_ingresso;
        $this->motivo_desvinculo = $motivo_desvinculo;
    }

    /**
     * Get the value of cidade
     */ 
    public function getCidade()
    {
        return $this->cidade;
    }

    /**
     * Set the value of cidade
     *
     * @return  self
     */ 
    public function setCidade($cidade)
    {
        $this->cidade = $cidade;

        return $this;
    }

    /**
     * Get the value of ano_desvinculo
     */ 
    public function getano_desvinculo()
    {
        return $this->ano_desvinculo;
    }

    /**
     * Set the value of ano_desvinculo
     *
     * @return  self
     */ 
    public function setano_desvinculo($ano_desvinculo)
    {
        $this->ano_desvinculo = $ano_desvinculo;

        return $this;
    }

    /**
     * Get the value of media_relativa
     */ 
    public function getMedia_relativa()
    {
        return $this->media_relativa;
    }

    /**
     * Set the value of media_relativa
     *
     * @return  self
     */ 
    public function setMedia_relativa($media_relativa)
    {
        $this->media_relativa = $media_relativa;

        return $this;
    }

    /**
     * Get the value of categoria_ingresso
     */ 
    public function getCategoria_ingresso()
    {
        return $this->categoria_ingresso;
    }

    /**
     * Set the value of categoria_ingresso
     *
     * @return  self
     */ 
    public function setCategoria_ingresso($categoria_ingresso)
    {
        $this->categoria_ingresso = $categoria_ingresso;

        return $this;
    }

    /**
     * Get the value of motivo_desvinculo
     */ 
    public function getMotivo_desvinculo()
    {
        return $this->motivo_desvinculo;
    }

    /**
     * Set the value of motivo_desvinculo
     *
     * @return  self
     */ 
    public function setMotivo_desvinculo($motivo_desvinculo)
    {
        $this->motivo_desvinculo = $motivo_desvinculo;

        return $this;
    }

    /**
     * Get the value of ano_vinculo
     */ 
    public function getAno_vinculo()
    {
        return $this->ano_vinculo;
    }

    /**
     * Set the value of ano_vinculo
     *
     * @return  self
     */ 
    public function setAno_vinculo($ano_vinculo)
    {
        $this->ano_vinculo = $ano_vinculo;

        return $this;
    }
}
