<?php

require_once './Camadas/Negocio/abstractprojeto.class.php';

class ProjetoExtensao extends Projeto{
}
