<?php

class Empresa{
    private $razao_social;
    private $capital_social;
    private $total_colaboradores;
    
    function __construct(
        $razao_social = null,
        $capital_social = null,
        $total_colaboradores = null) {

        $this->razao_social = $razao_social;
        $this->capital_social = $capital_social;
        $this->total_colaboradores = $total_colaboradores;
    }

    /**
     * Get the value of razao_social
     */ 
    public function getRazao_social()
    {
        return $this->razao_social;
    }

    /**
     * Set the value of razao_social
     *
     * @return  self
     */ 
    public function setRazao_social($razao_social)
    {
        $this->razao_social = $razao_social;

        return $this;
    }

    /**
     * Get the value of capital_social
     */ 
    public function getCapital_social()
    {
        return $this->capital_social;
    }

    /**
     * Set the value of capital_social
     *
     * @return  self
     */ 
    public function setCapital_social($capital_social)
    {
        $this->capital_social = $capital_social;

        return $this;
    }

    /**
     * Get the value of total_colaboradores
     */ 
    public function getTotal_colaboradores()
    {
        return $this->total_colaboradores;
    }

    /**
     * Set the value of total_colaboradores
     *
     * @return  self
     */ 
    public function setTotal_colaboradores($total_colaboradores)
    {
        $this->total_colaboradores = $total_colaboradores;

        return $this;
    }
}
