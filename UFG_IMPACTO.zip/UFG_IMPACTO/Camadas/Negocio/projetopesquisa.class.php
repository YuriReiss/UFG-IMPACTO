<?php

require_once './Camadas/Negocio/abstractprojeto.class.php';

class ProjetoPesquisa extends Projeto{
}
