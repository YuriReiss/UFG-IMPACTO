<?php
session_start();
//busca o arquivo controller dos projetos
require_once './MVC/Controller/projetocontroller.class.php';

$projetoController = new ProjetoController();

//destroi a variável $projetoController
unset($projetoController);