<?php
session_start();
//busca o arquivo controller das empresas
require_once './MVC/Controller/empresacontroller.class.php';

$empresaController = new EmpresaController();

//destroi a variável $empresaController
unset($empresaController);